import pandas as pd
import numpy as np

no_choice = False
def main():
 
    print("PuintoA")
    PuntoA()
    print("PuintoB")
    PuntoB()
    print("PuintoC")
    PuntoC()
    print("PuintoD")
    PuntoD()
    print ("Hervin Duvan Posso Peña")

def FillPrincipalDataFarames(SourceId):
    sw = {
      1: pd.read_csv("DataSources/exa_barrios_cali.csv"),
      2: pd.read_csv("DataSources/exa_dispositivos_cali.csv"),
      3: pd.read_csv("DataSources/exa_trx_clientes.csv"),     
    }
    return sw.get(SourceId, pd.DataFrame())
def ClearDataFrame (dfToClear):
    return dfToClear.iloc[0:0]

def Mark (DF):
    global  no_choice
    result = False
    if DF.numTrxPrev == 0: 
        result= True
    elif DF.numTrxPrev != 0 and DF.percentageCumulative >= 51.00 and DF.perCumprev <51.00: 
        result= True
    
    if DF.num_trx_x == DF.numTrxPrev and  no_choice == False :
        result=True
        
    if result == False: 
        no_choice = True
    else : no_choice = False
    return result

def haversine_distance(lat1, lon1, lat2, lon2):
   r = 6371
   phi1 = np.radians(lat1)
   phi2 = np.radians(lat2)
   delta_phi = np.radians(lat2-lat1)
   delta_lambda = np.radians(lon2-lon1)
   a = np.sin(delta_phi / 2)**2 + np.cos(phi1) * np.cos(phi2) *   np.sin(delta_lambda / 2)**2
   res = r * (2 * np.arctan2(np.sqrt(a), np.sqrt(1-a)))
   return np.round(res, 2)

def PuntoA():
    dfDistricts= FillPrincipalDataFarames(1)
    dfDevices= FillPrincipalDataFarames(2)
    dfClientsTransactions= FillPrincipalDataFarames(3)

    dfDevicesDistricts=pd.merge(left=dfDevices,right=dfDistricts,left_on="id_barrio",right_on="codigo",how="left")
    dfDevicesDistricts=dfDevicesDistricts.drop(columns='codigo_y')
    dfDevicesDistricts=dfDevicesDistricts.rename(columns={'codigo_x':'codigo'})
    dfClientsDevicesDistricts=pd.merge(left=dfClientsTransactions,right=dfDevicesDistricts,left_on=["cod_dispositivo","canal"],right_on=["codigo","tipo"],how="left")
    dfClientsDevicesDistricts=dfClientsDevicesDistricts[["num_doc","tipo_doc","id_barrio"]].drop_duplicates()
    dfClientsDevicesDistricts = dfClientsDevicesDistricts.groupby(['num_doc', 'tipo_doc']).size().reset_index(name='num_barrios')
    dfClientsDevicesDistricts = dfClientsDevicesDistricts.loc[(dfClientsDevicesDistricts["num_barrios"] >=3)]
    dfResult= dfClientsDevicesDistricts.sort_values(by='num_barrios', ascending=False)
    dfResult.to_csv("Results/ej_a.csv")
    print(dfResult)
    dfResult= ClearDataFrame(dfResult)

def PuntoB():
    dfClientsTransactions= FillPrincipalDataFarames(3)
    dfClientsTransactions = dfClientsTransactions.groupby(['num_doc','tipo_doc','canal'])['num_trx'].sum().reset_index()
    dfClientsTransactionsGeneral =  dfClientsTransactions.groupby(['num_doc','tipo_doc'])['num_trx'].sum().reset_index()
    dfTableMarge=pd.merge(left=dfClientsTransactions,right=dfClientsTransactionsGeneral,left_on=['num_doc','tipo_doc'],right_on=['num_doc','tipo_doc'],how="left")
    dfTableMarge['Percentage'] = (100 * dfTableMarge['num_trx_x']) / dfTableMarge["num_trx_y"]
    dfTableMarge = dfTableMarge.sort_values(by= ['num_doc', 'num_trx_x'], ascending=(False,False))
    dfTableMarge['percentageCumulative'] = dfTableMarge.groupby(['num_doc','tipo_doc'])['Percentage'].apply(lambda x: x.cumsum())
    dfTableMarge['numTrxPrev'] = dfTableMarge.groupby(['num_doc','tipo_doc'])['num_trx_x'].shift(fill_value=0)
    dfTableMarge['perCumprev'] = dfTableMarge.groupby(['num_doc','tipo_doc'])['percentageCumulative'].shift(fill_value=0)
    dfTableMarge['Visible'] = dfTableMarge.apply(Mark,axis= 1)
    dfResult = dfTableMarge[(dfTableMarge["Visible"] ==True)]
    dfResult = dfResult.rename(columns={"num_trx_x":"num_trx"})
    dfResult = dfResult.sort_values(by= ['num_doc', 'num_trx'], ascending=(False,False))    
    dfResult = dfResult[["num_doc","tipo_doc","canal","num_trx","Percentage"]]   
    dfResult.to_csv("Results/ej_b.csv")
    print(dfResult)
    dfResult= ClearDataFrame(dfResult) 

def PuntoC():
    dfDistricts= FillPrincipalDataFarames(1)
    dfDevices= FillPrincipalDataFarames(2)
    dfClientsTransactions= FillPrincipalDataFarames(3)
    dfDevicesDistricts=pd.merge(left=dfDevices,right=dfDistricts,left_on="id_barrio",right_on="codigo",how="left")
    dfDevicesDistricts=dfDevicesDistricts.drop(columns='codigo_y')
    dfDevicesDistricts=dfDevicesDistricts.rename(columns={'codigo_x':'codigo'})
    dfDistrictsClients=pd.merge(left=dfClientsTransactions,right=dfDevicesDistricts,left_on=["cod_dispositivo","canal"],right_on=["codigo","tipo"],how="left")
    dfDistrictsClients=dfDistrictsClients[["num_doc","tipo_doc","id_barrio","nombre"]].drop_duplicates()
    dfDistrictsClients = dfDistrictsClients.groupby(['id_barrio', 'nombre']).size().reset_index(name='num_Clientes')
    dfDistrictsClients= dfDistrictsClients.sort_values(by='num_Clientes', ascending=False)
    dfResult = dfDistrictsClients[0:10]
    dfResult.to_csv("Results/ej_c.csv")
    print(dfResult)
    dfResult= ClearDataFrame(dfResult)

def PuntoD():
    dfDevices= FillPrincipalDataFarames(2)
    dfDevices=dfDevices.loc[dfDevices.id_barrio==737998087]
    dfLocation=dfDevices[["latitud","longitud"]]
    dfLocation=dfLocation.drop_duplicates()
    dfLocation = dfLocation.assign(foo=1).merge(dfLocation.assign(foo=1), on='foo').drop('foo', 1)
    dfLocation = dfLocation.loc[(dfLocation["latitud_x"] != dfLocation["latitud_y"])& (dfLocation["longitud_x"] != dfLocation["longitud_y"])]
    latitude_x=0
    latitude_y=0
    longitude_x=0
    longitude_y=0
    kilometres=0
    for indexI, rowI in dfLocation.iterrows():           
        km=haversine_distance(rowI["latitud_x"],rowI["longitud_x"],rowI["latitud_y"],rowI["longitud_y"])
        if km>kilometres:
            latitude_x=rowI["latitud_x"]
            longitude_x=rowI["longitud_x"]
            latitude_y=rowI["latitud_y"]
            longitude_y=rowI["longitud_y"]
            kilometres=km
    
    srDevices_x=dfDevices[(dfDevices["latitud"]==latitude_x) & (dfDevices["longitud"]==longitude_x)]["codigo"]
    srDevices_y=dfDevices[(dfDevices["latitud"]==latitude_y ) & (dfDevices["longitud"]==longitude_y )]["codigo"]
    dfResult=pd.DataFrame({
    "Dispositivos  Ubicacion 1":list(srDevices_x),
    "Coordenadas Ubicacion 1": str(latitude_x ) + ','+ str(longitude_x ),
    "Dispositivos   Ubicacion 2":list(srDevices_y),
    "Coordenadas Ubicacion 2": str(latitude_y ) + ','+ str(longitude_y ),
    "Distancia":kilometres
    })
    dfResult.to_csv("Results/ej_d.csv")
    print(dfResult)
    dfResult= ClearDataFrame(dfResult)


if __name__== '__main__':
    main()