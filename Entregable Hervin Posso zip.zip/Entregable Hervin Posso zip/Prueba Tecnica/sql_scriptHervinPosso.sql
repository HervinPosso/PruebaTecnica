
SCRIPTS:
-------------------------------------------------------------------------------------------------  
-- PUNTO A
-- Author:  - HERVIN DUVAN POSSO PEÑA   
-- Description: La vista realiza un inner join entre las tablas exa_trx_clientes y exa_dispositivos_cali
-- realizando una agrupación por la información que identifica al cliente, para luego realizar
-- un conteo de los barrios sobre los cuales a realizados transacciones; al final se condiciona la vista a solo aquellos cliente con mas de 3 barrios
-------------------------------------------------------------------------------------------------  

CREATE VIEW vwPuntoA AS

	SELECT C.num_doc,C.tipo_doc, COUNT(DISTINCT D.id_barrio) num_barrios
	FROM exa_trx_clientes C JOIN exa_dispositivos_cali D ON C.cod_dispositivo = D.codigo AND C.canal = D.tipo
	GROUP BY C.num_doc, C.tipo_doc
	HAVING COUNT(DISTINCT D.id_barrio) >= 3



-------------------------------------------------------------------------------------------------  
-- PUNTO B
-- Author:  - HERVIN DUVAN POSSO PEÑA   
-- Description: Este procedimiento almacenado utiliza tablas temporales WITH para ir agregando columnas necesarias
-- para la logica del procedimiento, el resultado es almacenado en una tabla temporal #TEMPORAL_FINAL   usada para alimentar el cursor. 
-- La logica esta explicada en el documento pdf, en el apartado Analisis.
-- 
-------------------------------------------------------------------------------------------------  

CREATE PROCEDURE [dbo].[ClientesCanales]
AS
BEGIN


	DECLARE @Temporal TABLE (
		num_doc [varchar](50) NULL,
		canal [varchar](50) NULL ,
		trx INT NULL,	
		Total_Trx INT NULL,
		Porcentaje DECIMAL(5,2)NULL) 
    DECLARE @num_doc varchar(50) ,
		@canal varchar(50)  ,
		@trx INT ,
		@CantidadRegistros INT ,
		@Total_Trx INT ,
		@Porcentaje DECIMAL(5,2),
		@Anterior INT ,
		@PorcentajeAcomulado DECIMAL(5,2),
		@AcomuladoAnterior DECIMAL(5,2) ,
		@Bandera BIT	
		
		;

	WITH Agrupamiento AS (
	 SELECT [num_doc],[canal] ,SUM(CONVERT(INT,[num_trx])) trx
	  FROM [PruebaTecnica].[dbo].[exa_trx_clientes]
	  GROUP BY [num_doc],[canal]),
	  PrimerProcesado AS (
	  SELECT *, COUNT(num_doc) OVER (PARTITION BY NUM_DOC) CantidadRegistros, SUM(trx) OVER (PARTITION BY NUM_DOC) Total_Trx
	  FROM Agrupamiento ), 
	  SegundoProcesado AS (
	  SELECT num_doc,canal,trx,CantidadRegistros,Total_Trx, 
	  ROUND(((trx*100.0)/Total_Trx),1,0) Porcentaje,
	  LAG(trx,1,0) OVER (PARTITION BY NUM_DOC ORDER BY NUM_DOC,TRX desc)Anterior,
	  SUM(ROUND(((trx*100.0)/Total_Trx),1,0)) Over (PARTITION BY Num_doc Order by Num_doc,TRX desc  
	  Rows Between Unbounded Preceding and Current Row) as PorcentajeAcomulado
	  FROM PrimerProcesado  ),
	  FINAL AS (SELECT *, LAG(PorcentajeAcomulado,1,0) OVER (PARTITION BY NUM_DOC ORDER BY NUM_DOC,TRX desc)AcomuladoAnterior FROM SegundoProcesado)

	  SELECT *
	  INTO #TEMPORAL
	  FROM FINAL



	SET @Bandera = 0

	DECLARE Calificacion_Cursor CURSOR fast_forward read_only
		FOR SELECT  num_doc,canal,trx,CantidadRegistros,Total_Trx,Porcentaje,Anterior,PorcentajeAcomulado,AcomuladoAnterior
		FROM #TEMPORAL   
	  ORDER BY  num_doc,trx DESC   

	OPEN Calificacion_Cursor
	FETCH NEXT FROM Calificacion_Cursor
	INTO		  @num_doc,@canal,@trx,@CantidadRegistros,@Total_Trx,@Porcentaje,@Anterior,@PorcentajeAcomulado,@AcomuladoAnterior
	WHILE @@FETCH_STATUS = 0
	BEGIN
			DECLARE @Result BIT
       
			 SELECT @Result = CASE WHEN @Anterior = 0  THEN 1   ELSE CASE WHEN @Anterior != 0 AND @PorcentajeAcomulado >= 51 
			 AND @AcomuladoAnterior < 51 THEN 1  WHEN @trx = @Anterior AND @Bandera = 0 THEN 1 ELSE 0 END END 
			IF ( @Result = 0)  SET @Bandera = 1
			ELSE 
			BEGIN 
			 SET @Bandera = 0
			 INSERT INTO @Temporal SELECT  @num_doc,@canal,@trx,@Total_Trx,@Porcentaje
			END
		  
		FETCH NEXT FROM Calificacion_Cursor
		INTO	 @num_doc,@canal,@trx,@CantidadRegistros,@Total_Trx,@Porcentaje,@Anterior,@PorcentajeAcomulado,@AcomuladoAnterior

	END

	CLOSE Calificacion_Cursor
	DEALLOCATE Calificacion_Cursor

	SELECT num_doc,canal,trx,Total_Trx,Porcentaje FROM @Temporal ORDER BY num_doc, trx DESC 

END



-------------------------------------------------------------------------------------------------  
-- PUNTO C
-- Author:  - HERVIN DUVAN POSSO PEÑA   
-- Description: La vista realiza un inner join entre las tablas  exa_barrios_cali  Y exa_dispositivos_cali, exa_dispositivos_cali y  exa_trx_clientes 
-- 
-------------------------------------------------------------------------------------------------  

CREATE VIEW vwPuntoC AS

	SELECT  B.codigo,B.nombre, COUNT(DISTINCT C.num_doc) num_clientes
	FROM exa_barrios_cali B JOIN exa_dispositivos_cali D ON B.codigo = D.id_barrio
	JOIN exa_trx_clientes C  ON C.cod_dispositivo = D.codigo AND C.canal = D.tipo
	GROUP BY B.codigo,B.nombre


----------  
-- PUNTO D
-- Author:  - HERVIN DUVAN POSSO PEÑA   
-- Funcion para realizar el calculo de las distancias
-- 
-------------------------------------------------------------------------------------------------  

CREATE FUNCTION [dbo].[fnsCalculateDistance](@Latitude1 FLOAT,@longitude1 FLOAT,@latitude2 FLOAT,@longitude2 FLOAT,@MeasureUnit CHAR(1))
RETURNS FLOAT
AS BEGIN


    DECLARE @EarthRadius FLOAT =  6378.137 
    DECLARE @dLat FLOAT = RADIANS(@latitude2 - @Latitude1)
    DECLARE @dLon FLOAT = RADIANS(@longitude2 - @longitude1) 
    SET @Latitude1 = RADIANS(@Latitude1)
    SET @latitude2 = RADIANS(@latitude2)

    DECLARE @a FLOAT
	DECLARE @result FLOAT
    SET @a = POWER(SIN(@dLat/2),2) + COS(@Latitude1)*COS(@latitude2)*POWER(SIN(@dLon/2),2)
    SET @result = 2 * ASIN(SQRT(@a)) * @EarthRadius

	IF @MeasureUnit = 'M' 
		SET @result = @result *1000

	RETURN @result
END
GO


----------  
-- PUNTO D
-- Author:  - HERVIN DUVAN POSSO PEÑA   
-- Funcion tabular que devuelve el los dispositivos mas alejados entre si.
--  la logica esta explicada en el documento pdf.
-- 
-------------------------------------------------------------------------------------------------  

CREATE FUNCTION [dbo].[fntCalculateDistance](@Latitude1 FLOAT,@longitude1 FLOAT,@latitude2 FLOAT,@longitude2 FLOAT,@MeasureUnit CHAR(1))
RETURNS FLOAT
AS BEGIN


    DECLARE @EarthRadius FLOAT =  6378.137 
    DECLARE @dLat FLOAT = RADIANS(@latitude2 - @Latitude1)
    DECLARE @dLon FLOAT = RADIANS(@longitude2 - @longitude1) 
    SET @Latitude1 = RADIANS(@Latitude1)
    SET @latitude2 = RADIANS(@latitude2)

    DECLARE @a FLOAT
	DECLARE @result FLOAT
    SET @a = POWER(SIN(@dLat/2),2) + COS(@Latitude1)*COS(@latitude2)*POWER(SIN(@dLon/2),2)
    SET @result = 2 * ASIN(SQRT(@a)) * @EarthRadius

	IF @MeasureUnit = 'M' 
		SET @result = @result *1000

	RETURN @result
END
GO


----------------------------
EJECUCIONES

Punto A : 
SELECT num_doc,tipo_doc,num_barrios FROM vwPuntoA ORDER BY num_barrios DESC


Punto B : 
EXEC [ClientesCanales]

Punto C :
SELECT TOP 10  codigo, nombre, num_clientes FROM vwPuntoC ORDER BY num_clientes DESC

Punto D :
 SELECT * FROM  dbo.distant_coordinates('737998087','K')